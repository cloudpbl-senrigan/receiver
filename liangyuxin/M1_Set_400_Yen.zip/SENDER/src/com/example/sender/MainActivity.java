package com.example.sender;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import android.app.Activity;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
//import android.widget.Toast;

public class MainActivity extends Activity {

  private ToneGenerator toneGenerator = new ToneGenerator(
  AudioManager.STREAM_SYSTEM, ToneGenerator.MAX_VOLUME);
  private StringBuffer cbuf = new StringBuffer(128);
  int n;
  private DatagramSocket ds;
  private DatagramSocket ds2;
  private DatagramPacket dp;
  private DatagramPacket dp2;
  private String IP_remote= "172.20.10.11"; //IP�A�h���X;
  private String IP_remote2= "172.20.10.9"; //IP�A�h���X;
  private int port_remote = 1234;;//�|�[�g�ԍ� 
  //GPS��臒l�ݒ�
  public static final double GPS_Range = 1.0 / 10000;//�ܓx�E�o�x�̃O���b�h�̑傫��(�����l)
  private double GPS_Time = 1.0;
  //GPS�擾�֌W
  private LocationManager lm;
  private long significantlyNewer = 2 * 60 * 1000L;
  String latitude = "not used";
  String longtitude = "not used";
  //String lastLatitude = "none";
  //String lastLongtitude = "none";
  
  boolean activKey = false;

  @Override  
  public void onCreate(Bundle savedInstanceState) {   
    super.onCreate(savedInstanceState);
    lm = (LocationManager)getSystemService(LOCATION_SERVICE);
 
    LinearLayout linearLayout = new LinearLayout(this);
    linearLayout.setOrientation(LinearLayout.VERTICAL);
    final Button button1 = new Button(this);
    final Button button3 = new Button(this);
    Button button2 = new Button(this);
    final TextView tv = new TextView(this);
    final TextView tv2 = new TextView(this);
    tv.setText("�J�E���^");
    button1.setText("Generate Trigger");
    button3.setText("Activate GPS");
    button2.setText("Reset");

      
      
    //���C�A�E�g
    linearLayout.addView(button1, new LinearLayout.LayoutParams(
    LinearLayout.LayoutParams.WRAP_CONTENT, 
    LinearLayout.LayoutParams.WRAP_CONTENT));
    linearLayout.addView(button3, new LinearLayout.LayoutParams(
    LinearLayout.LayoutParams.WRAP_CONTENT, 
    LinearLayout.LayoutParams.WRAP_CONTENT));
    linearLayout.addView(button2, new LinearLayout.LayoutParams(
    LinearLayout.LayoutParams.WRAP_CONTENT, 
    LinearLayout.LayoutParams.WRAP_CONTENT));
    linearLayout.addView(tv, new LinearLayout.LayoutParams(
    LinearLayout.LayoutParams.WRAP_CONTENT, 
    LinearLayout.LayoutParams.WRAP_CONTENT));
    linearLayout.addView(tv2, new LinearLayout.LayoutParams(
    LinearLayout.LayoutParams.WRAP_CONTENT, 
    LinearLayout.LayoutParams.WRAP_CONTENT));
    setContentView(linearLayout);
  

      // Button1 ���N���b�N���ꂽ���ɌĂяo�����R�[���o�b�N��o�^   
      button1.setOnClickListener(new View.OnClickListener() {   
        public void onClick(View v) {   
          n++;
          // ����������
          cbuf.append(n);
          tv.setText(cbuf.toString());  // tv �ɂ� final ���K�v  
          cbuf.delete(0, 99);
          toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP);

          // UDP�@���M                     
          new Thread(new Runnable() {
            public void run() {                 
              try{      
            	InetAddress host = InetAddress.getByName(IP_remote);
            	InetAddress host2 = InetAddress.getByName(IP_remote2);
            	String message = "1";  // ���M���b�Z�[�W     
                        ds = new DatagramSocket();  //DatagramSocket �쐬
                        ds2 = new DatagramSocket();  //DatagramSocket �쐬
                        byte[] data = message.getBytes();       
                        dp = new DatagramPacket(data, data.length, host, port_remote);  //DatagramPacket �쐬 
                        dp2 = new DatagramPacket(data, data.length, host2, port_remote);  //DatagramPacket �쐬 
                        ds2.send(dp2);
                        ds.send(dp);
                        tv2.setText("���M�������܂���");
                        GPS_Time+=GPS_Time+1;
                     }catch(Exception e){
                        System.err.println("Exception : " + e);
                        //tv2.setText("���M���s���܂���" + e);
                     }          
            }
          }).start();
        } 
        
      });
      
      // Button3 ���N���b�N���ꂽ���ɌĂяo�����R�[���o�b�N��o�^   
      button3.setOnClickListener(new View.OnClickListener() {   
        public void onClick(View v) {
        	  double[] place = new double[2];
        	  double[] lastPlace = new double[2];
        	activKey = true; 
        	lastPlace[0] =0.0;
        	lastPlace[1] =0.0;
        	place[0] =0.0;
        	place[1] =0.0;

        	while (activKey != false && GPS_Time <= 30) {
        		
        		Location location = getLastKnownLocation();
        		place[0] = location.getLatitude();
        		place[1] = location.getLongitude();
        		
        		latitude = String.valueOf(location.getLatitude());
        		longtitude = String.valueOf(location.getLongitude());
        		if ((place[0] - lastPlace[0]) >=GPS_Range){
        			//�E�����Ɉړ�
        			if ((place[1] - lastPlace[1]) >=GPS_Range){
        				//�E��ړ�
        				button1 .performClick();
        				lastPlace[0] = place[0];
        				lastPlace[1] = place[1];
        			} else if ((place[1] - lastPlace[1]) <= (GPS_Range*-1)){
        				//�E���ړ�
        				button1 .performClick();
        				lastPlace[0] = place[0];
        				lastPlace[1] = place[1];
        			}else {
        				//�E�ړ�
        				button1 .performClick();
        				lastPlace[0] = place[0];
        			}     				
        		} else if ((place[0] - lastPlace[0]) <= (GPS_Range * -1)){
        			//�������Ɉړ�
        			if ((place[1] - lastPlace[1]) >=GPS_Range){
        				//�E��ړ�
        				button1 .performClick();
        				lastPlace[0] = place[0];
        				lastPlace[1] = place[1];
        			} else if ((place[1] - lastPlace[1]) <= (GPS_Range*-1)){
        				//�E���ړ�
        				button1 .performClick();
        				lastPlace[0] = place[0];
        				lastPlace[1] = place[1];
        			}else {
        				//�E�ړ�
        				button1 .performClick();
        				lastPlace[0] = place[0];
        			}
        		} else {
        			if ((place[1] - lastPlace[1]) >=GPS_Range){
        				//��ړ�
        				button1 .performClick();
        				lastPlace[1] = place[1];
        			} else if ((place[1] - lastPlace[1]) <= (GPS_Range*-1)){
        				//���ړ�
        				button1 .performClick();
        				lastPlace[1] = place[1];
        			}else {
        				//�ړ��Ȃ�
        				//Toast.makeText(getApplication(), "" + activKey, Toast.LENGTH_LONG).show();
   //     				button1 .performClick();
        			}
        		}     			
        		
        		
        		try{
        			Thread.sleep(1000);
        			}catch(InterruptedException ex){
        			}
        			
        	
        	
        	/*
        	// �ʒu���̍X�V���󂯎��悤�ɐݒ�
            lm.requestLocationUpdates(
            		LocationManager.GPS_PROVIDER, // �v���o�C�_
            GPS_Time, // �ʒm�̂��߂̍ŏ����ԊԊu
            GPS_Range, // �ʒm�̂��߂̍ŏ������Ԋu
            new LocationListener(){// �ʒu��񃊃X�i�[,this�̓o�O������http://stackoverflow.com/questions/17119968/android-locationmanager-requestlocationupdates-doesnt-work
            	@Override
            	public void onStatusChanged(String provider, int status, Bundle extras) {
                }
        	    @Override
        	    public void onProviderEnabled(String provider) {
        	    }
        	    @Override
        	    public void onProviderDisabled(String provider) {
        	    }
        	    @Override
        	    public void onLocationChanged(final Location location) {
                    	
            	}
            });
            
  
            */
        }
        	//lm=null;
        }
      });
      
      
      // �J�E���^�̌��� 
      button2.setOnClickListener(new View.OnClickListener() {   
    	 public void onClick(View v) {
    	  activKey = false;
          n--;
          cbuf.append(n);
          tv.setText(cbuf.toString());  
          cbuf.delete(0, 99);
          //toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP);
        } 
      });   

    n=0;        // �J�E���g�l�̏����l
    try{        
      InetAddress host = InetAddress.getByName(IP_remote);      // IP�A�h���X
      String message = "send by Android";  // ���M���b�Z�[�W     
      ds = new DatagramSocket();  //DatagramSocket �쐬
      byte[] data = message.getBytes(); 
      dp = new DatagramPacket(data, data.length, host, port_remote);  //DatagramPacket �쐬                               
      tv2.setText("���������������܂���");
    }catch(Exception e){
      System.err.println("Exception : " + e);
      tv2.setText("�������Ɏ��s���܂���");
    }
  // end OnCreat()   
  }
  
    protected void onResume() {      
        super.onResume();
    }
    
    @Override
    protected void onPause() {
        //if (lm != null) {
         //   lm.removeUpdates((LocationListener) this);
        //}
        
        super.onPause();
    }

    public void onStop() {
    	//if (lm != null) {
          //  lm.removeUpdates((LocationListener) this);
        //}
        
        super.onPause();

    }
    
    public Location getLastKnownLocation() {
		return getLastKnownLocation(new String[]{ LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER });
	}
    
    /**
	 * �w�肳�ꂽ�ʒu���v���o�C�_���ʎq�̗񋓂��g�p���čŗǂ� LastKnownLocation ���擾���ĕԂ��܂��B
	 *
	 * @param providers �ʒu���v���o�C�_���ʎq�̗�
	 * @return �ŗǂ� LastKnownLocation �܂��� <code>null</code>
	 * @throws IllegalArgumentException �ʒu���v���o�C�_���ʎq���s���ȏꍇ
	 * @see {@link LocationManager#getLastKnownLocation(String)}
	 */
	
    public Location getLastKnownLocation(final String[] providers) throws IllegalArgumentException {
		if (lm == null || providers == null) {
			return null;
		}

		Location result = null;
		for (final String provider : providers) {
			if (provider != null && lm.isProviderEnabled(provider)) {
				final Location lastKnownLocation = lm.getLastKnownLocation(provider);
				if (isBetterLocation(result, lastKnownLocation)) {
					result = lastKnownLocation;
				}
			}
		}
		return result;
	}
	
	public boolean isBetterLocation(final Location currentLocation, final Location newLocation) {
		return true;
	}
	/*	if (newLocation == null) {
			// �V�����ʒu��� null �̏ꍇ�͏�ɖ����Ɣ��f���܂��B
			return false;
		}
		if (currentLocation == null) {
			return true;
		}

		// Check whether the new location fix is newer or older
		final long timeDelta = newLocation.getTime() - currentLocation.getTime();
		if (timeDelta > significantlyNewer) {
			return true;
		} else if (timeDelta < significantlyNewer) {
			return false;
		}

		// Check whether the new location fix is more or less accurate

		if (!newLocation.hasAccuracy()) {
			return false;
		}
		if (!currentLocation.hasAccuracy()) {
			return true;
		}


		final int accuracyDelta = (int) (newLocation.getAccuracy() - currentLocation.getAccuracy());
		if (accuracyDelta < 0) {
			return true;
		} else if (timeDelta > 0 && accuracyDelta <= 0) {
			return true;
		} else if (timeDelta > 0 && accuracyDelta <= 200 ) {
			return true;
		}
		return false;
	}
	
*/    
}















        
    

    
    
  