package com.example.sample;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.hardware.Camera;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.MediaStore.Images;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Toast;



@SuppressLint("SimpleDateFormat") public class SampleLoc extends Activity implements LocationListener {
	
	//GPS��臒l�ݒ�
	public static final int GPS_Range = 1;
	public static final int GPS_Time = 123;
	//GPS�擾�֌W
	private LocationManager lm;

	//�A���h���C�h�ԒʐM
//	private final String TAG = getClass().getSimpleName();
	private Bt mBt;	
	private ArrayAdapter<String> mCandidateServers;
	private ArrayAdapter<String> mServers;
	private View mView;
	private final Handler mHandler = new Handler();
	
	// �J�����C���X�^���X
    private Camera mCam = null;
    // �J�����v���r���[�N���X
    private CameraPreview mCamPreview = null;
    // �J�n�{�^����2�x�����֎~�p�t���O
    //private boolean mIsTake = false;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //BLUETOOTH SET UP
        setContentView(R.layout.activity_sample_loc);    
        mCandidateServers = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
		mServers = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
		mBt = new Bt(this, mCandidateServers, mServers);	     
        
		// ���P�[�V�����}�l�[�W���̃C���X�^���X���擾����
        lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);                         
        // �J�����C���X�^���X�̎擾
        try {
            mCam = Camera.open();
        } catch (Exception e) {
            // �G���[
            this.finish();
        }
        // FrameLayout �� CameraPreview �N���X��ݒ�
        FrameLayout preview = (FrameLayout)findViewById(R.id.cameraPreview);
        mCamPreview = new CameraPreview(this, mCam);
        preview.addView(mCamPreview);
        
        //�T�[�o�[���X�C�b�`
        Button btnStart = (Button)findViewById(R.id.btnStart);
        btnStart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	//mBt.startDiscoverable();
    			//mBt.startServer();
            	Toast.makeText(getApplicationContext(), ""+ mBt.getBoard(), Toast.LENGTH_SHORT).show();
    			if (mBt.isConnected()) {
    				//�ڑ�����
    				Toast.makeText(getApplicationContext(), "Server", Toast.LENGTH_LONG).show();
    				String message = mBt.getBoard().put(1, 1);
            		if (message != null) {
            			invalidate();
            			mBt.sendMessage(message);	
            		}
    				startGPS();
    			}
                
            }
        });
        
        //���炢����Ƒ��X�C�b�`
        Button btnStop = (Button)findViewById(R.id.btnStop);
        btnStop.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	// �����ɏ������L�q
            	//clientSearch();
            	Toast.makeText(getApplicationContext(), ""+ mBt.getBoard(), Toast.LENGTH_SHORT).show();
            	if (mBt.isConnected()) {
            		//receive protocol
            		Toast.makeText(getApplicationContext(), "Client", Toast.LENGTH_LONG).show();
            		takePhoto();
            	}
            	
            }
        });
    }    
    
    @Override
	protected void onResume() {
		super.onResume();
		//mBt.turnOn();
	}
    
    @Override
    protected void onPause() {
        super.onPause();
        //lm.removeUpdates(pi);
        //mBt.cancel();
        //lm.removeUpdates(this);
        // �J�����j���C���X�^���X�����
        if (mCam != null) {
            mCam.release();
            mCam = null;
        }
    }
    public void onStop() {
    	super.onStop();
    	 
    	// �ʒu���̍X�V���~�߂�
    	//lm.removeUpdates(this);
    	 
    }

    
    //�摜�֌W�̏���
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.sample_loc, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	int itemId = item.getItemId();	  	
       	// Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        if (itemId == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		int itemId = item.getItemId();
		if (itemId == R.id.menu_discoverable) {
			mBt.startDiscoverable();
		} else if (itemId == R.id.menu_start_server) {
			mBt.startServer();
		} else if (itemId == R.id.menu_search_server) {
			mCandidateServers.clear();
			ListView lv = new ListView(this);
			lv.setAdapter(mCandidateServers);
			lv.setScrollingCacheEnabled(false);
			final AlertDialog dialog = new AlertDialog.Builder(this)
			.setTitle(R.string.title_dialog)
			.setPositiveButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					mBt.cancelDiscovery();
				}
			})
			.setView(lv)
			.create();
			lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> items, View view, int position, long id) {
					dialog.dismiss();
					String address = mCandidateServers.getItem(position);
					if (mServers.getPosition(address) == -1) {
						mServers.add(address);
					}
					mBt.cancelDiscovery();
				}
			});
			dialog.show();
			mBt.searchServer();
		} else if (itemId == R.id.menu_connect) {
			ListView lv = new ListView(this);
			final AlertDialog dialog = new AlertDialog.Builder(this)
			.setTitle(R.string.title_dialog)
			.setPositiveButton(android.R.string.cancel, null)
			.setView(lv)
			.create();
			lv.setAdapter(mServers);
			lv.setScrollingCacheEnabled(false);
			lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> items, View view, int position, long id) {
					dialog.dismiss();
					String address = mServers.getItem(position);
					mBt.connect(address);
				}
			});
			dialog.show();
		}
		return true;
	}

    private void takePhoto(){
    	int time = 0;//�������[�v�΍� 
    	while (time != 300000000) {
    		if (mBt.isConnected() && mBt.getBoard().check() == "1,1") {
    			mCam.takePicture(null, null, mPicJpgListener);
    			String message = mBt.getBoard().put(0, 0);
    			if (message != null) {
    				invalidate();
    				mBt.sendMessage(message);
    			}
    			time = 0;
    		}	
    		time++; 
    	}
    }
    
    //�N���C�G���g���R�l�N�V�����n��
	private void clientSearch(){
		mCandidateServers.clear();
		ListView lv = new ListView(this);
		lv.setAdapter(mCandidateServers);
		lv.setScrollingCacheEnabled(false);
		final AlertDialog dialog = new AlertDialog.Builder(this)
		.setTitle(R.string.title_dialog)
		.setPositiveButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				mBt.cancelDiscovery();
			}
		})
		.setView(lv)
		.create();
		lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> items, View view, int position, long id) {
				dialog.dismiss();
				String address = mCandidateServers.getItem(position);
				if (mServers.getPosition(address) == -1) {
					mServers.add(address);
				}
				mBt.cancelDiscovery();
			}
		});
		mBt.searchServer();
		lv = new ListView(this);
		lv.setAdapter(mServers);
		lv.setScrollingCacheEnabled(false);
		lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> items, View view, int position, long id) {
				dialog.dismiss();
				String address = mServers.getItem(position);
				mBt.connect(address);
			}
		});
		dialog.show();
		//�����܂Őڑ����m�F���ꂸ
    	Toast.makeText(getApplicationContext(), ""+ mBt.getBoard(), Toast.LENGTH_SHORT).show();
	}



	

    //GPS�������ʐ^���
    private void startGPS(){
    	//���[�P�[�V�����擾�����̐ݒ�
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_COARSE);
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        criteria.setSpeedRequired(false);
        criteria.setAltitudeRequired(false);
        criteria.setBearingRequired(false);
        criteria.setCostAllowed(false);
        // �ʒu���̍X�V���󂯎��悤�ɐݒ�
        lm.requestLocationUpdates(
        		LocationManager.GPS_PROVIDER, // �v���o�C�_
        GPS_Time, // �ʒm�̂��߂̍ŏ����ԊԊu
        GPS_Range, // �ʒm�̂��߂̍ŏ������Ԋu
        new LocationListener(){// �ʒu��񃊃X�i�[,this�̓o�O������http://stackoverflow.com/questions/17119968/android-locationmanager-requestlocationupdates-doesnt-work
        	@Override
        	public void onStatusChanged(String provider, int status, Bundle extras) {        		
       		if (mBt.isConnected()) {
        			mCam.takePicture(null, null, mPicJpgListener);
        			String message = mBt.getBoard().put(1, 1);
        			if (message != null) {
        				invalidate();
        				mBt.sendMessage(message);
        			}
        		}
        	}
    	    @Override
    	    public void onProviderEnabled(String provider) {
    	    }
    	    @Override
    	    public void onProviderDisabled(String provider) {
    	    }
    	    @Override
    	    public void onLocationChanged(final Location location) {
        		if (mBt.isConnected()) {
        			mCam.takePicture(null, null, mPicJpgListener);
        			String message = mBt.getBoard().put(1, 1);
        			if (message != null) {
        				invalidate();
        				mBt.sendMessage(message);
        			}
        		}
    	    }
        }); 
    }
  /**/  
    /**
     * JPEG �f�[�^�����������̃R�[���o�b�N
     */
    private Camera.PictureCallback mPicJpgListener = new Camera.PictureCallback() {
        public void onPictureTaken(byte[] data, Camera camera) {
            if (data == null) {
                return;
            }

            //�t�@�C���̒u���ꏊ�F�f�t�H���g�ۑ��ʒu/test
            String saveDir = Environment.getExternalStorageDirectory().getPath() + "/test";        
            File file = new File(saveDir);

            // �t�H���_�쐬
            if (!file.exists()) {
                if (!file.mkdir()) {
                    Log.e("Debug", "Make Dir Error");
                }
            }

            // �摜�ۑ��p�X
            Calendar cal = Calendar.getInstance();
            SimpleDateFormat sf = new SimpleDateFormat("yyyyMMdd_HHmmss");
            String imgPath = saveDir + "/" + sf.format(cal.getTime()) + ".jpg";

            // �t�@�C���ۑ�
            FileOutputStream fos;
            try {
                fos = new FileOutputStream(imgPath, true);
                fos.write(data);
                fos.close();

                // �A���h���C�h�̃f�[�^�x�[�X�֓o�^
                // (�o�^���Ȃ��ƃM�������[�Ȃǂɂ����ɔ��f����Ȃ�����)
                registAndroidDB(imgPath);

            } catch (Exception e) {
                Log.e("Debug", e.getMessage());
            }

            fos = null;

            // takePicture ����ƃv���r���[����~����̂ŁA�ēx�v���r���[�X�^�[�g
            mCam.startPreview();

            //mIsTake = false;
        }
    };

    /**
     * �A���h���C�h�̃f�[�^�x�[�X�։摜�̃p�X��o�^
     * @param path �o�^����p�X
     */
    private void registAndroidDB(String path) {
        // �A���h���C�h�̃f�[�^�x�[�X�֓o�^
        // (�o�^���Ȃ��ƃM�������[�Ȃǂɂ����ɔ��f����Ȃ�����)
        ContentValues values = new ContentValues();
        ContentResolver contentResolver = SampleLoc.this.getContentResolver();
        values.put(Images.Media.MIME_TYPE, "image/jpeg");
        values.put("_data", path);
        contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
    }
    
    

	
  //GPS�֌W�̏���
    public void onLocationChanged(Location location) {
    	// ��Ƃ��ă��x���Ɏ擾�����ʒu��\��
    	//TextView latitudeLabel = new TextView(null);
    	//TextView longitudeLabel = new TextView(null);
		//latitudeLabel.setText(Double.toString(location.getLatitude()));
    	//longitudeLabel.setText(Double.toString(location.getLongitude()));
    	 
    }
    	 
    public void onProviderEnabled(String provider) {
     
    }
    	 
    public void onProviderDisabled(String provider) {
     
    }
    	 
    public void onStatusChanged(String provider, int status, Bundle extras) {
    	 
    }    
    
    
  //Bluetooth
    @Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		mBt.onActivityResult(requestCode, resultCode, data);
	}


	public void invalidate() {
		// TODO Auto-generated method stub
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				mView.invalidate();
			}
		});
	}

    
}



